let agenda = ["https://calzetonia.com/wp-content/uploads/2020/04/ea72ee53-1.jpg", "https://pandasneakers.es/wp-content/uploads/2021/06/nike-air-jordan-x-dior-hombre-1575528357-1.jpg"];

// Función IIFE
(function () {
    let storageImagen = JSON.parse(window.localStorage.getItem("imgdew"));
    if (storageImagen === null || storageImagen.length === 0) {
        storageImagen = localStorage.setItem("imgdew", JSON.stringify(agenda));
    }
    agenda = JSON.parse(localStorage.getItem("imgdew", JSON.stringify(agenda)));
    newlist = document.createElement("div")
    newlist.setAttribute("class", "lista-imagenes")
    document.body.insertAdjacentElement("afterend", newlist)

    agenda.forEach(i => {
        newdiv = document.createElement("div")
        newdiv.setAttribute("class", "imagen")
        newimg = document.createElement("img")
        newimg.setAttribute("src", i)
        newdiv.insertAdjacentElement("beforeend", newimg);

        document.getElementsByClassName("lista-imagenes")[0].insertAdjacentElement("afterbegin", newdiv)
    });
    // Lista de imágenes que se mostrarán de forma dinámica ...
})()

function Añadir(url) {
    agenda.push(url);
    newdiv = document.createElement("div")
    newdiv.setAttribute("class", "imagen")

    newimg = document.createElement("img")
    newimg.setAttribute("src", agenda[agenda.length - 1])
    newdiv.insertAdjacentElement("afterbegin", newimg);
    document.getElementsByClassName("imagen")[0].insertAdjacentElement("beforebegin", newdiv)
    storageImagen = localStorage.setItem("imgdew", JSON.stringify(agenda));
}